Write-Host "Starting CodeCSVUpload App..." -ForegroundColor Green
Write-Host ""
Write-Host "The app will be available at: http://localhost:5000" -ForegroundColor Yellow
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""
npm run dev

